<div id="event_selection">
		<form id="form_change_event" method="POST">
			<?php
				echo 'Event-Auswahl: <select  id="event" type="text" name="event" size="1">';
				$res_event = mysqli_query($db,"SELECT * FROM event order by event_id desc;");
           
				while($row = mysqli_fetch_array($res_event))
				{
					if($row['event_id'] == $_SESSION['event'])
					{
						echo '<option value="'.$row['event_id'].'" selected>'.$row['event_name'].'</option>';
					}
					else
					{
						echo '<option value="'.$row['event_id'].'">'.$row['event_name'].'</option>';
					}
					
				}	
				echo '</select><br>';
			?>
			<input type="submit" name="submit" value="Bestätigen"/>
		</form>		
</div>

<?php

	if(isset($_POST['submit']))
	{
		$_SESSION['event'] = $_POST['event'];
	}

?>


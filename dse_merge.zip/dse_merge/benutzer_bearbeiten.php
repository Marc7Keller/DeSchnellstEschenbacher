<!DOCTYPE html>
<html>

    <head>
        <title>Administration - Benutzer bearbeiten</title>
        <link rel="stylesheet" href="_css/style.css" type="text/css">
        <link rel="stylesheet" href="_css/style_benutzer.css" type="text/css">
        
        <?php
		include("php/config.php");
		include("includes/sessions.php");
        include 'includes/incl_benutzer_bearbeiten_form.php'
        ?>
    </head>

    <body>

        <div id="sitediv">

            <a href="index.php"><img id="scdiemberg_logo" src="_img/sportclubdiemberg_logo_klein.png"/></a>
            <a href="index.php"><img id="deschnellsteschenbacher_logo" src="_img/deschnellsteschenbacher_logo_klein.png"/></a>

            <?php
             include 'includes/navigation.php';
			  include 'includes/event_selection.php';
            ?>

            <div id="content">

			<?php
			if(isset($_POST["benutzername"]))
			{
			if($_POST["passwort"] == $_POST["passwort_wdh"])
			{
			$sql = "UPDATE `sport_program`.`admin` SET `username` = '".$_POST["benutzername"]."', `password` = '".$_POST["passwort"]."' WHERE `admin`.`admin_id` = ".$_POST['admin_id'].";";
			$res = mysqli_query($db,$sql);
			}
			else
			{
			echo "Passwörter stimmen nicht überein";
			}
			}
			?>
			
			
                <h1 id="site_title">Benutzer bearbeiten</h1>
				
                <form id="form_verwaltung" action="" method="POST">
                <label style="font-weight: bold;">Benutzer:</label>
                <select  id="benutzer_combo" type="text" name="benutzer_combo" size="1">
				<?php
					$sql = "SELECT * FROM `admin`;";
					$res = mysqli_query($db,$sql);
					while($row = mysqli_fetch_array($res))
					{
						$admin_id = $_POST['benutzer_combo'];
						if($_POST['benutzer_combo']== $row['admin_id'])
						{
						echo "<option selected = true value = '".$row['admin_id']."'>".$row['username']."</option>";
						}
						else
						{
						echo "<option value = '".$row['admin_id']."'>".$row['username']."</option>";
						}
					}
				?>
                </select></br></br>
				  <input id="speichern_button"type="submit" name="submit" value="Speichern"/>
                </form>
				
				 <form id="form_verwaltung" action="" method="POST">
                    </br><p style="font-size: 11px;">Felder mit * markiert sind Pflichtfelder</p></br>
                Benutzername:*				<input id="benutzername" type="text" name="benutzername"/></br>
                Passwort:*					<input  id="passwort" type="password" name="passwort"/></br>
                Passwort wiederholen:*		<input  id="passwort_wdh" type="password" name="passwort_wdh"/></br></br>

				 <input  id="admin_id" type="hidden" name="admin_id" value="<?php echo $_POST['benutzer_combo']; ?>"/></br>
				
                <p style="font-weight: bold">Wählen Sie die gewünschten Berechtigungen:</p></br>
                <input type="checkbox" name="berechtigungen" value="zeit_erfassen"> Zeit erfassen</br> 
                <input type="checkbox" name="berechtigungen" value="teilnehmer_erfassen"> Teilnehmer erfassen</br> 
                <input type="checkbox" name="berechtigungen" value="benutzer_hinzufuegen"> Benutzer hinzufügen</br>
                <input type="checkbox" name="berechtigungen" value="alle_rechte"> Alle Rechte (Administrator)</br></br>
                <input id="speichern_button"type="submit" name="submit" value="Speichern"/>
                </form>
			
				<?php 
				echo "<br><br><br><br>";
				
				$sql = "SELECT * FROM `admin`;";
				$res = mysqli_query($db,$sql);
				 if(mysqli_num_rows($res) >= 1)
				 {	 
					echo '<table border="1" style="width:100%">'; 
					echo "<tr><th>ID</th><th>username</th></tr>"; 
					while($row = mysqli_fetch_array($res))
					{
					  echo "<tr><td>"; 
					  echo $row['admin_id'];
					  echo "</td><td>"; 
					  echo $row['username'];
					  echo "</td></tr>"; 
					}
					echo "</table>";
				 }
				 else 
				 {
					echo "There was no matching record for the name " . $searchTerm;
				 }
				
			?>		
			<br>
                </div>

                <div id="footer">
                </div>


        </div>
    </body>

</html>